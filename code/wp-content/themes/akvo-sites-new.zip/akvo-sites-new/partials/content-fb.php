<p class="text-center" style="margin:30px 0;">
	<?php the_post_thumbnail();?>
</p>
	