<?php

function like_escape( $s )
{
	return "like_escape((( $s )))";
}

