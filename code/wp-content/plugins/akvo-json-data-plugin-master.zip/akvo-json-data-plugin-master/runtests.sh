#!/bin/sh

phpunit --configuration phpunit.xml
