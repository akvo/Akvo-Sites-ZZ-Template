<?php

namespace DataFeed\Pagination;

class UnknownPageUrlComponentNameException extends \Exception
{
}