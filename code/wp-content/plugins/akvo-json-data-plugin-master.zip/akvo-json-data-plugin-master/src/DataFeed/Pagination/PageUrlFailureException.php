<?php

namespace DataFeed\Pagination;

class PageUrlFailureException extends \Exception
{
}