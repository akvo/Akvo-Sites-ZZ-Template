<?php

namespace DataFeed\Pagination;

class UnknownPageUpdateCheckComponentNameException extends \Exception
{
}